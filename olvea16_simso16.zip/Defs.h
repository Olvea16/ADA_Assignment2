#pragma once

typedef int arrayType;